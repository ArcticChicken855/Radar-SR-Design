from .mimose import DeviceMimose
